import React from 'react';
import UserService from './UserService';
import Home from "./Home"
class Singlechat extends React.Component{
render(){
    return(
        <div>
          
<div class="row">
    <div class="col mx-2 ">
<Home />
    </div>
    <div class="col-1 ">

    </div>
    <div class='col border-start '>
    <div class="row mb-2 border-bottom ">
  <div class="col-1">
<img src="https://rukminim1.flixcart.com/image/300/300/k0vbgy80pkrrdj/speaker/mobile-tablet-speaker/4/n/n/boat-stone-grenade-original-imafg96ffpnpgdv4.jpeg?q=90"class="card-img" alt="image"></img>
  </div>
  <div class="col">
    <h5 class="card-title" style={{textDecoration:"none"}}>Flipkart Support</h5>
    </div>
    </div>
    <div class="row">
      Send a message to start chatting
    </div>
    </div>
</div>

            </div>
    );
}
}
export default Singlechat;