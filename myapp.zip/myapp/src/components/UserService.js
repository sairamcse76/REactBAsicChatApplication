import axios from 'axios'
const Api_URL='https://my-json-server.typicode.com/codebuds-fk/chat/chats';
class UserService{
    getUsers(){
        return axios.get(Api_URL);
    }
}
export default new UserService();