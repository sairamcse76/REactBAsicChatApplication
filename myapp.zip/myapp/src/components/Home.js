import React from 'react';
import UserService from './UserService';
class Home extends React.Component{
  constructor(props){
    super(props)
    this.state={
      users:[],
      filterlist:[],
      value :"",
    }
    this.handleChange=this.handleChange.bind(this);
    this.handleSubmit=this.handleSubmit.bind(this);
  }
  handleChange(event){
    this.setState(
      {
        value:event.target.value
      }
    );
  }
  handleSubmit(event){
    
  }
  componentDidMount(){
    UserService.getUsers().then((response)=>{
      this.setState({users:response.data})
      this.setState({filterlist:response.data})
      console.log(this.state)
    }
    );
  }
render(){
  const {users}=this.state;
  const {filterlist}=this.state
  const filterItem=(item)=>{
const updateditems=users.filter((users)=>
users.title===item);
this.setState({filterlist:updateditems})
  };
    return(
        <div>
    <div class="col mx-2 "> 
<form class="form-floating " onSubmit={this.handleSubmit}>
<div class="row">
        <div class="col">
  <input type="text" class="form-control" id="floatingInputValue" onChange={this.handleChange} placeholder="Start typing to search" value={this.state.value}></input>
  <label for="floatingInputValue">Filter by id/ Order value</label>
  </div>
  <div class="col-1">
  <button class="btn  btn-outline-primary" type="button" value="search" onClick={()=>filterItem(this.state.value)}>SEARCH</button>
  </div>
  </div>
</form>

{ 
this.state.filterlist.map(
  user=>
<div class="row mb-2" key={user.id}>
  <div class="col-1">
<img src={user.imageURL} class="card-img" alt="image"></img>
  </div>
  <div class="col">
<div class="card">
 <a class="card-block streched-link text-decoration-none" href="" onclick>
  <div class="card-body">
    <h5 class="card-title" style={{textDecoration:"none"}}>{user.title}</h5>
    <h6 class="card-subtitle mb-2 text-muted">{user.orderId}</h6>

    <p card="card-text">
    
    Recent message
     
      </p>
  </div>
  </a>
</div>

</div>

<div class="col-2">
  <h6>18/12/2021</h6>
</div>
</div>
)
}
</div>

            </div>
    );
}
}
export default Home;