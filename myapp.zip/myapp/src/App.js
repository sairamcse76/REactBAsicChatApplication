import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import Singlechat from './components/Singlechat';
function App() {
  return (
    <div className="App">
<Singlechat/>
    </div>
  );
}

export default App;
